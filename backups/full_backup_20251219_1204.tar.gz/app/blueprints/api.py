from flask import Blueprint, jsonify, request, make_response, current_app
from .auth import login_required
from ..db import log_audit
from ..services.remote import RemoteExecutor
import os

api_bp = Blueprint('api', __name__)

@api_bp.route('/api/view_log', methods=['GET'])
@login_required
def api_view_log():
    try:
        executor = RemoteExecutor(current_app.config['GLOBAL_SERVER_IP'])
        log_path = current_app.config['REMOTE_LOG_PATH']
        # Leemos las ultimas 1000 lineas usando PowerShell
        cmd = f'Get-Content -Path "{log_path}" -Tail 1000 -Encoding UTF8'
        success, content = executor.run_ps_command(cmd)
        
        if success:
            return jsonify({"status": "ok", "content": content})
        else:
            return jsonify({"status": "error", "content": "Error leyendo log remoto: " + content}), 500
    except Exception as e:
        return jsonify({"status": "error", "content": str(e)}), 500

@api_bp.route('/api/download_log', methods=['GET'])
@login_required
def api_download_log():
    try:
        executor = RemoteExecutor(current_app.config['GLOBAL_SERVER_IP'])
        log_path = current_app.config['REMOTE_LOG_PATH']
        # Leemos el log para descarga (limitado a ultimas 5000 lineas por performance)
        cmd = f'Get-Content -Path "{log_path}" -Tail 5000 -Encoding UTF8'
        success, content = executor.run_ps_command(cmd)
        
        if success:
            response = make_response(content)
            response.headers["Content-Disposition"] = "attachment; filename=robocopy_log_recent.txt"
            response.headers["Content-type"] = "text/plain; charset=utf-8"
            return response
        else:
            return "Error recuperando log para descarga: " + content, 500
    except Exception as e:
        return str(e), 500

@api_bp.route('/api/backup_event', methods=['POST'])
def api_backup_event():
    """Endpoint para recibir eventos de backup desde SERVERGLOBAL"""
    # Autenticación con token simple
    auth_token = request.headers.get('X-Auth-Token')
    if auth_token != 'BACKUP_SECRET_TOKEN_2024':
        return jsonify({"error": "Unauthorized"}), 401
    
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    action = data.get('action')
    details = data.get('details', '')
    
    if action not in ['BACKUP_START', 'BACKUP_END']:
        return jsonify({"error": "Invalid action"}), 400
    
    # Usar el resultado enviado o inferir uno por defecto
    result = data.get('result')
    if not result:
        result = 'INFO' if action == 'BACKUP_START' else 'SUCCESS'
        
    log_audit(action, details, result, 'SYSTEM_BACKUP')
    
    return jsonify({"status": "OK", "message": "Event logged successfully"}), 200
