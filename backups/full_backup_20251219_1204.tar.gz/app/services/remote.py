import winrm
from flask import current_app

class RemoteExecutor:
    def __init__(self, target_ip):
        self.target_ip = target_ip
        self.user = current_app.config['WINDOWS_USER']
        self.password = current_app.config['WINDOWS_PASS']
        self.session = None

    def _get_session(self):
        """Lazy initialization of WinRM session"""
        if not self.session:
            # Endpoint standar para WinRM HTTP
            url = f"http://{self.target_ip}:5985/wsman"
            self.session = winrm.Session(url, auth=(self.user, self.password), transport='ntlm')
        return self.session

    def run_ps_command(self, ps_script_block):
        """Executes a PowerShell command or script block"""
        try:
            s = self._get_session()
            # Envolvemos el comando en powershell.exe para asegurar contexto
            # O usamos run_ps de la libreria si disponible, pero run_cmd es mas directo
            # Codificar script complejo en Base64 a veces es mejor, pero probemos directo primero
            # Para comandos simples 'run_ps' de winrm suele ser: run_ps(script)
            
            rs = s.run_ps(ps_script_block)
            
            stdout = rs.std_out.decode('utf-8', errors='replace')
            stderr = rs.std_err.decode('utf-8', errors='replace')
            
            if rs.status_code == 0:
                print(f"[{self.target_ip}] SUCCESS")
                return True, stdout
            else:
                print(f"[{self.target_ip}] ERROR: {stderr}")
                return False, stderr + "\n" + stdout
                
        except Exception as e:
            return False, str(e)

    def run_cmd(self, command):
        """Executes a standard CMD command"""
        try:
            s = self._get_session()
            rs = s.run_cmd(command)
            stdout = rs.std_out.decode('cp850', errors='replace') # Windows legacy codepage
            stderr = rs.std_err.decode('cp850', errors='replace')
            if rs.status_code == 0: return True, stdout
            else: return False, stderr
        except Exception as e:
            return False, str(e)
